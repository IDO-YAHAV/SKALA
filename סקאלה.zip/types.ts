
export interface Spectrum {
  id: string;
  left: string;
  right: string;
}

export enum Team { // May be less relevant in the new flow, or represent individual players
  Team1 = 'שחקן 1', // Placeholder, will be dynamic with player names
  Team2 = 'קבוצה 2', // Placeholder
}

export enum GamePhase {
  PLAYER_DETAILS_SETUP = 'PLAYER_DETAILS_SETUP', // Player enters name, chooses avatar
  ROOM_SETUP = 'ROOM_SETUP', // Host room or join room
  CLUE_PREPARATION = 'CLUE_PREPARATION', // Timer runs, players input clues for their spectrums
  GUESSING_ROUND = 'GUESSING_ROUND',   // A prepared clue is shown, team guesses
  REVEAL_SCORE = 'REVEAL_SCORE',     // Target and score are revealed for the round
  GAME_SUMMARY = 'GAME_SUMMARY',     // Game over, show final scores
  // Old phases to be reviewed/removed if not used by new flow:
  // WELCOME = 'WELCOME',
  // SETUP_ROUND = 'SETUP_ROUND',
  // PSYCHIC_VIEW = 'PSYCHIC_VIEW',
  // CLUE_INPUT = 'CLUE_INPUT',
  // TEAM_GUESS = 'TEAM_GUESS',
  // REVEAL = 'REVEAL',
  // GAME_OVER = 'GAME_OVER',
}

export interface Player {
  id: string;
  name: string;
  avatar: string;
  score: number;
}

export interface PreparedClue {
  playerId: string; // ID of the player who prepared this clue
  spectrum: Spectrum;
  targetPosition: number;
  clue: string;
  isUsed: boolean; // To track if this clue has been used in a guessing round
}

export interface GameState {
  phase: GamePhase;
  localPlayer: Player | null; // Details of the user playing on this client
  roomPlayers: Player[]; // List of all players in the room
  roomId: string | null;
  isHost: boolean;

  // Clue Preparation Phase
  cluePreparationTimeLeft: number; // Seconds
  spectrumsToPrepare: { spectrum: Spectrum, targetPosition: number }[]; // Spectrums assigned to localPlayer for clue prep
  preparedClues: PreparedClue[]; // All clues prepared by all players (or just local for now)
  
  // Guessing Round
  currentSpectrum: Spectrum | null; // The spectrum for the current guessing round
  targetPosition: number | null; // Hidden from team during guess
  currentGuess: number | null; // 0-100, team's guess
  clue: string; // The active clue for the current round
  clueGiverId: string | null; // ID of player whose clue is being guessed

  // Scoring and Game Flow
  scores: { [playerId: string]: number }; // More flexible scoring
  roundLog: RoundLogEntry[];
  
  // Old fields to re-evaluate:
  activeTeam: Team; // May be replaced by clueGiverId or guessingPlayerIds
  psychicTeam: Team | null; // Role changes, re-evaluate
  
  // New field to track current clue being guessed from the prepared list
  currentPreparedClueIndex: number | null;
  cluesForCurrentGame: PreparedClue[]; // Populated after CLUE_PREPARATION
}

export interface RoundLogEntry {
  spectrum: Spectrum;
  clue: string;
  target: number;
  guess: number;
  score: number;
  team: string; // Player ID or team name
  clueGiverId: string;
}

export interface ScoringBand {
  points: number;
  range: number; // +/- this value from target
}


import { Spectrum, ScoringBand } from './types';

export const SPECTRUMS_HE: Spectrum[] = [
  { id: '1', left: 'סרט גרוע', right: 'סרט טוב' },
  { id: '2', left: 'קר', right: 'חם' },
  { id: '3', left: 'מיותר', right: 'חיוני' },
  { id: '4', left: 'לא אופנתי', right: 'אופנתי' },
  { id: '5', left: 'קל', right: 'קשה' },
  { id: '6', left: 'מוערך בחסר', right: 'מוערך ביתר' },
  { id: '7', left: 'מלוכלך', right: 'נקי' },
  { id: '8', left: 'לא פופולרי', right: 'פופולרי' },
  { id: '9', left: 'זול', right: 'יקר' },
  { id: '10', left: 'מריח רע', right: 'מריח טוב' },
  { id: '11', left: 'מסוכן', right: 'בטוח' },
  { id: '12', left: 'משעמם', right: 'מרגש' },
  { id: '13', left: 'רע לתקופה זו', right: 'טוב לתקופה זו' },
  { id: '14', left: 'אדם רגיל', right: 'אדם משוגע' },
  { id: '15', left: 'מזויף', right: 'אמיתי' },
];

export const WINNING_SCORE = 10; // Per player or team

export const SCORING_BANDS: ScoringBand[] = [
  { points: 4, range: 3 }, 
  { points: 3, range: 7 }, 
  { points: 2, range: 12 },
];

export const TARGET_CENTER_MIN = 15; 
export const TARGET_CENTER_MAX = 85;

export const AVATAR_OPTIONS: string[] = [
  "https://avatar.iran.liara.run/public/boy?username=PurpleSpike",
  "https://avatar.iran.liara.run/public/girl?username=OrangeBlob",
  "https://avatar.iran.liara.run/public/boy?username=RedStarSmile",
  "https://avatar.iran.liara.run/public/girl?username=GreenPotSad",
  "https://avatar.iran.liara.run/public/boy?username=BlueWink",
  "https://avatar.iran.liara.run/public/girl?username=OrangeFlower",
];

export const CLUE_PREPARATION_DURATION_SECONDS = 120; // 2 minutes
export const NUMBER_OF_CLUES_TO_PREPARE = 2; // Each player prepares 2 clues
export const MOCK_ROOM_ID = "1234"; // For joining room simulation

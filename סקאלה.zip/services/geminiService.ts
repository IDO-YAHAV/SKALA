
import { GoogleGenAI, GenerateContentResponse, Chat } from "@google/genai";

// Assumes process.env.API_KEY is pre-configured, valid, and accessible 
// in the execution environment as per project guidelines.

export class GeminiService {
  private ai: GoogleGenAI;
  private textModel = 'gemini-2.5-flash-preview-04-17';
  // private imageModel = 'imagen-3.0-generate-002'; // For image generation

  constructor() {
    // Directly use process.env.API_KEY. The '!' asserts it's non-null,
    // based on the assumption it's always provided in the environment.
    // If process.env.API_KEY is not set, this will cause a runtime error
    // when trying to use `this.ai`, or GoogleGenAI constructor might throw.
    // This aligns with the "assume it's pre-configured" guideline.
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
  }

  async generateText(prompt: string, systemInstruction?: string): Promise<string | null> {
    try {
      const response: GenerateContentResponse = await this.ai.models.generateContent({
        model: this.textModel,
        contents: prompt,
        config: {
          ...(systemInstruction && { systemInstruction }),
          // thinkingConfig: { thinkingBudget: 0 } // Example: disable thinking for low latency
        },
      });
      return response.text;
    } catch (error) {
      console.error("Error generating text with Gemini:", error);
      // It might be useful to return the error message or a more specific error type
      return null;
    }
  }

  async generateJson(prompt: string, systemInstruction?: string): Promise<any | null> {
    try {
      const response: GenerateContentResponse = await this.ai.models.generateContent({
        model: this.textModel,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          ...(systemInstruction && { systemInstruction }),
        },
      });
      
      let jsonStr = response.text.trim();
      const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; // Matches optional language and newlines
      const match = jsonStr.match(fenceRegex);
      if (match && match[2]) {
        jsonStr = match[2].trim(); // Extract content within fences and trim
      }

      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error("Failed to parse JSON response from Gemini. Raw text:", response.text, "Parsed text attempt:", jsonStr, "Error:", e);
        return null;
      }
    } catch (error) {
      console.error("Error generating JSON with Gemini:", error);
      return null;
    }
  }
  
  startChat(systemInstruction?: string): Chat | null {
    try {
        return this.ai.chats.create({
            model: this.textModel,
            config: {
                ...(systemInstruction && { systemInstruction }),
            }
        });
    } catch (error) {
        console.error("Error starting chat with Gemini:", error);
        return null;
    }
  }
}

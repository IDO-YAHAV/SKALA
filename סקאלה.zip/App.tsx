
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { GamePhase, Team, GameState, Spectrum, RoundLogEntry, Player, PreparedClue } from './types';
import { SPECTRUMS_HE, WINNING_SCORE, SCORING_BANDS, TARGET_CENTER_MIN, TARGET_CENTER_MAX, CLUE_PREPARATION_DURATION_SECONDS, NUMBER_OF_CLUES_TO_PREPARE, MOCK_ROOM_ID } from './constants';

import HomePage from './components/HomePage';
import RoomPage from './components/RoomPage';
import CluePreparationPage from './components/CluePreparationPage';
import Scoreboard from './components/Scoreboard';
import SpectrumDisplay from './components/SpectrumDisplay';
import TargetSlider from './components/TargetSlider';
import ClueArea from './components/ClueArea';
import GamePhaseMessage from './components/GamePhaseMessage';

const initialGameState: GameState = {
  phase: GamePhase.PLAYER_DETAILS_SETUP,
  localPlayer: null,
  roomPlayers: [],
  roomId: null,
  isHost: false,
  cluePreparationTimeLeft: CLUE_PREPARATION_DURATION_SECONDS,
  spectrumsToPrepare: [],
  preparedClues: [],
  currentSpectrum: null,
  targetPosition: null,
  currentGuess: 50,
  clue: '',
  clueGiverId: null,
  scores: {},
  roundLog: [],
  activeTeam: Team.Team1, // Placeholder, review usage
  psychicTeam: null, // Placeholder, review usage
  currentPreparedClueIndex: null,
  cluesForCurrentGame: [],
};

const WS_URL = 'ws://localhost:8080/ws'; // Placeholder for your WebSocket server URL

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(initialGameState);
  const [availableSpectrums, setAvailableSpectrums] = useState<Spectrum[]>([...SPECTRUMS_HE]);
  const timerRef = useRef<number | null>(null);

  const socketRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);

  // Effect to execute pending action once WebSocket is connected
  useEffect(() => {
    if (isConnected && pendingAction) {
      console.log("WebSocket connected, executing pending action.");
      pendingAction();
      setPendingAction(null);
    }
  }, [isConnected, pendingAction]);

  const connectWebSocket = useCallback(() => {
    if (socketRef.current && (socketRef.current.readyState === WebSocket.OPEN || socketRef.current.readyState === WebSocket.CONNECTING)) {
      console.log("WebSocket already open or connecting.");
      if(socketRef.current.readyState === WebSocket.OPEN) setIsConnected(true); // Ensure state is accurate
      return;
    }

    console.log(`Attempting to connect to WebSocket at ${WS_URL}...`);
    setIsConnecting(true);
    setIsConnected(false); // Explicitly set to false while connecting
    
    const ws = new WebSocket(WS_URL);
    socketRef.current = ws;

    ws.onopen = () => {
      console.log("WebSocket connection established.");
      setIsConnected(true);
      setIsConnecting(false);
      if (gameState.localPlayer) {
        ws.send(JSON.stringify({ type: 'PLAYER_ONLINE', payload: { player: gameState.localPlayer } }));
      }
    };

    ws.onmessage = (event) => {
      console.log("WebSocket message received:", event.data);
      try {
        const message = JSON.parse(event.data as string);
        // TODO: Handle server messages to update gameState
        // e.g., if (message.type === 'ROOM_CREATED') { 
        //   setGameState(prev => ({...prev, roomId: message.payload.roomId, isHost: true, roomPlayers: message.payload.players}));
        // }
      } catch (error) {
        console.error("Failed to parse WebSocket message or invalid JSON:", error, event.data);
      }
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      setIsConnected(false);
      setIsConnecting(false);
      // Potentially show error to user
    };

    ws.onclose = (event) => {
      console.log(`WebSocket connection closed: code=${event.code}, reason=${event.reason}, wasClean=${event.wasClean}`);
      setIsConnected(false);
      setIsConnecting(false);
      socketRef.current = null; // Clean up the ref
      // Potentially attempt to reconnect here based on event.code or if !event.wasClean
    };
  }, [gameState.localPlayer]); // Dependency on localPlayer for PLAYER_ONLINE message

  // Cleanup WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (socketRef.current) {
        console.log("Closing WebSocket connection on component unmount.");
        // Clear handlers to prevent them from being called on a closed socket during cleanup
        socketRef.current.onopen = null;
        socketRef.current.onmessage = null;
        socketRef.current.onerror = null;
        socketRef.current.onclose = null;
        if (socketRef.current.readyState === WebSocket.OPEN) {
          socketRef.current.close(1000, "Client unmounting");
        }
        socketRef.current = null;
      }
    };
  }, []);


  // Player Setup
  const handlePlayerDetailsSubmit = useCallback((name: string, avatar: string) => {
    const newPlayer: Player = { id: Date.now().toString(), name, avatar, score: 0 };
    setGameState(prev => ({
      ...prev,
      localPlayer: newPlayer,
      roomPlayers: [newPlayer],
      scores: { [newPlayer.id]: 0 },
      phase: GamePhase.ROOM_SETUP,
    }));
  }, []);

  // Room Setup
  const handleHostRoom = useCallback(() => {
    const action = () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.localPlayer) {
        console.log("Sending HOST_ROOM message");
        socketRef.current.send(JSON.stringify({ type: 'HOST_ROOM', payload: { player: gameState.localPlayer } }));
        // Optimistic UI update. Server will send definitive state.
        // The roomId will eventually come from the server in a ROOM_CREATED message.
        const mockNewRoomId = Math.floor(1000 + Math.random() * 9000).toString();
        setGameState(prev => ({ ...prev, roomId: mockNewRoomId, isHost: true }));
      } else {
        console.warn("Could not send HOST_ROOM: WebSocket not open or localPlayer not set.");
      }
    };

    if (isConnected) {
      action();
    } else {
      connectWebSocket();
      setPendingAction(() => action);
    }
  }, [connectWebSocket, gameState.localPlayer, isConnected]);

  const handleJoinRoom = useCallback((roomIdInput: string) => {
    const action = () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.localPlayer) {
        console.log(`Sending JOIN_ROOM message for room: ${roomIdInput}`);
        socketRef.current.send(JSON.stringify({ type: 'JOIN_ROOM', payload: { roomId: roomIdInput, player: gameState.localPlayer } }));
        
        // Optimistic UI update. Server will confirm/deny and send actual room state.
        // For now, allow MOCK_ROOM_ID for testing other parts of the flow locally.
        if (roomIdInput === MOCK_ROOM_ID) { 
             setGameState(prev => ({ ...prev, roomId: roomIdInput, isHost: false }));
        } else {
             // For non-mock rooms, we're just sending the message.
             // UI might show "Joining room..." until server responds.
             // For now, also optimistically set for testing purposes.
             setGameState(prev => ({ ...prev, roomId: roomIdInput, isHost: false }));
             console.log("Attempting to join non-mock room. Server will validate.");
        }
      } else {
        console.warn("Could not send JOIN_ROOM: WebSocket not open or localPlayer not set.");
      }
    };

    if (isConnected) {
      action();
    } else {
      connectWebSocket();
      setPendingAction(() => action);
    }
  }, [connectWebSocket, gameState.localPlayer, isConnected]);


  const startCluePreparationPhase = useCallback(() => {
    // This logic will largely move to the server.
    // Client will send a START_GAME message, server assigns spectrums.
    // For now, keeping client-side logic for testing flow.
    console.log("Attempting to start clue preparation phase. In future, this sends START_GAME to server.");
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.roomId && gameState.isHost) {
        socketRef.current.send(JSON.stringify({ type: 'START_GAME', payload: { roomId: gameState.roomId } }));
    } else {
        console.warn("Cannot send START_GAME: Not host, no room ID, or WebSocket not open.");
    }

    let currentSpectrums = [...availableSpectrums];
    if (currentSpectrums.length < NUMBER_OF_CLUES_TO_PREPARE) {
      currentSpectrums = [...SPECTRUMS_HE]; 
    }

    const selectedForPreparation: { spectrum: Spectrum, targetPosition: number }[] = [];
    const usedSpectrumIds = new Set<string>();

    for (let i = 0; i < NUMBER_OF_CLUES_TO_PREPARE; i++) {
      let spectrumIndex: number;
      let selectedSpectrum: Spectrum;
      do {
        spectrumIndex = Math.floor(Math.random() * currentSpectrums.length);
        selectedSpectrum = currentSpectrums[spectrumIndex];
      } while (usedSpectrumIds.has(selectedSpectrum.id) && currentSpectrums.length > usedSpectrumIds.size);
      
      usedSpectrumIds.add(selectedSpectrum.id);
      const target = Math.floor(Math.random() * (TARGET_CENTER_MAX - TARGET_CENTER_MIN + 1)) + TARGET_CENTER_MIN;
      selectedForPreparation.push({ spectrum: selectedSpectrum, targetPosition: target });
    }
    
    setAvailableSpectrums(prev => prev.filter(s => !usedSpectrumIds.has(s.id)));

    setGameState(prev => ({
      ...prev,
      phase: GamePhase.CLUE_PREPARATION,
      spectrumsToPrepare: selectedForPreparation,
      cluePreparationTimeLeft: CLUE_PREPARATION_DURATION_SECONDS,
      preparedClues: [], 
    }));
  }, [availableSpectrums, gameState.roomId, gameState.isHost]);


  const startGuessingRounds = useCallback(() => {
    // This will be triggered by a server message.
    console.log("Starting guessing rounds (currently client-side, will be server-driven).");
    setGameState(prev => ({
      ...prev,
      cluesForCurrentGame: [...prev.preparedClues], 
      currentPreparedClueIndex: -1, 
      phase: GamePhase.GUESSING_ROUND, 
    }));
  }, []); 

  const handleClueSubmittedDuringPrep = useCallback((clueText: string, spectrum: Spectrum, target: number) => {
    if (!gameState.localPlayer || !gameState.roomId) return;
    const newPreparedClue: PreparedClue = {
      playerId: gameState.localPlayer.id,
      spectrum,
      targetPosition: target,
      clue: clueText,
      isUsed: false,
    };
    
    // Send clue to server
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify({ 
            type: 'SUBMIT_CLUE', 
            payload: { roomId: gameState.roomId, clue: newPreparedClue }
        }));
    } else {
        console.warn("WebSocket not open. Clue submitted locally only.");
    }

    setGameState(prev => ({
      ...prev,
      preparedClues: [...prev.preparedClues, newPreparedClue],
    }));
  }, [gameState.localPlayer, gameState.roomId]);

  const finishCluePreparation = useCallback(() => {
     if (timerRef.current) clearTimeout(timerRef.current);
     // Validation logic remains for now
     if (gameState.preparedClues.length < gameState.spectrumsToPrepare.length && gameState.preparedClues.length < NUMBER_OF_CLUES_TO_PREPARE) {
        alert(`נא להכין רמזים עבור כל הספקטרומים שהוקצו (${gameState.preparedClues.length}/${NUMBER_OF_CLUES_TO_PREPARE})`);
        return;
    }
    if (gameState.preparedClues.length === 0) {
        alert("יש להכין לפחות רמז אחד!");
        return;
    }

    // Inform server that this player has finished preparation
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.roomId && gameState.localPlayer) {
        socketRef.current.send(JSON.stringify({ 
            type: 'FINISH_CLUE_PREP', 
            payload: { roomId: gameState.roomId, playerId: gameState.localPlayer.id }
        }));
    } else {
        console.warn("WebSocket not open. Finishing clue prep locally.");
    }
    // Transition to guessing rounds will eventually be server-driven based on all players finishing or timer.
    // For now, local transition:
    startGuessingRounds();
  }, [gameState.preparedClues, gameState.spectrumsToPrepare, startGuessingRounds, gameState.roomId, gameState.localPlayer]);


  useEffect(() => {
    if (gameState.phase === GamePhase.CLUE_PREPARATION && gameState.cluePreparationTimeLeft > 0) {
      timerRef.current = window.setTimeout(() => {
        setGameState(prev => ({ ...prev, cluePreparationTimeLeft: prev.cluePreparationTimeLeft - 1 }));
      }, 1000);
    } else if (gameState.phase === GamePhase.CLUE_PREPARATION && gameState.cluePreparationTimeLeft === 0) {
      if (timerRef.current) clearTimeout(timerRef.current);
      // Server will handle timeout logic. Client might just display "Time's up!"
      // For now, if clues were prepared, proceed.
      if (gameState.preparedClues.length > 0) {
         console.log("Clue prep timer ended. Client forcing startGuessingRounds if clues exist.");
         // Inform server about timeout from client side (server should ideally manage this)
        if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.roomId && gameState.localPlayer) {
            socketRef.current.send(JSON.stringify({ 
                type: 'CLUE_PREP_TIMEOUT', 
                payload: { roomId: gameState.roomId, playerId: gameState.localPlayer.id }
            }));
        }
         startGuessingRounds(); 
      } else {
        alert("לא הוכנו רמזים בזמן! נסה שוב.");
        // This transition will also be server-driven (e.g., to a waiting state or new round setup)
        setGameState(prev => ({...prev, phase: GamePhase.ROOM_SETUP})); 
      }
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [gameState.phase, gameState.cluePreparationTimeLeft, gameState.preparedClues, startGuessingRounds, gameState.roomId, gameState.localPlayer]);
  
  const setupNextGuessingRound = useCallback(() => {
    // This logic will be entirely server-driven.
    // Server sends a message like 'NEXT_ROUND_DATA' with the clue, spectrum, clue giver.
    console.log("Setting up next guessing round (client-side, will be server-driven).");
    const { cluesForCurrentGame } = gameState; 
    let nextClueIndex = (gameState.currentPreparedClueIndex ?? -1) + 1;

    while(nextClueIndex < cluesForCurrentGame.length && cluesForCurrentGame[nextClueIndex].isUsed) {
        nextClueIndex++;
    }

    if (nextClueIndex >= cluesForCurrentGame.length) {
      setGameState(prev => ({ ...prev, phase: GamePhase.GAME_SUMMARY }));
      return;
    }
    
    const currentClueData = cluesForCurrentGame[nextClueIndex];
    
    const updatedCluesForCurrentGame = cluesForCurrentGame.map((clue, index) => 
        index === nextClueIndex ? { ...clue, isUsed: true } : clue
    );

    setGameState(prev => ({
      ...prev,
      currentSpectrum: currentClueData.spectrum,
      targetPosition: currentClueData.targetPosition, // Target is hidden from guessers by UI logic
      clue: currentClueData.clue,
      clueGiverId: currentClueData.playerId,
      currentGuess: 50, 
      phase: GamePhase.GUESSING_ROUND,
      currentPreparedClueIndex: nextClueIndex,
      cluesForCurrentGame: updatedCluesForCurrentGame,
    }));

  }, [gameState]); 

   useEffect(() => {
    if (gameState.phase === GamePhase.GUESSING_ROUND && gameState.currentSpectrum === null) { 
      // This condition signifies needing the next round's data.
      // In a server-driven model, the client wouldn't call setupNextGuessingRound directly like this.
      // It would wait for the server to send the data for the round.
      setupNextGuessingRound();
    }
  }, [gameState.phase, gameState.currentSpectrum, setupNextGuessingRound]);


  const handleGuessChange = useCallback((guess: number) => {
    setGameState(prev => ({ ...prev, currentGuess: guess }));
  }, []);

  const handleLockGuess = useCallback(() => {
    // Send guess to server
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.roomId && gameState.localPlayer && gameState.currentGuess !== null) {
        socketRef.current.send(JSON.stringify({
            type: 'SUBMIT_GUESS',
            payload: { 
                roomId: gameState.roomId, 
                playerId: gameState.localPlayer.id, 
                guess: gameState.currentGuess,
                clueGiverId: gameState.clueGiverId // Server needs to know whose clue this guess is for
            }
        }));
    } else {
        console.warn("WebSocket not open or missing data. Guess locked locally only.");
    }
    // Transition to REVEAL_SCORE will be server-driven after processing the guess.
    // For now, optimistic local transition:
    setGameState(prev => ({ ...prev, phase: GamePhase.REVEAL_SCORE }));
  }, [gameState.roomId, gameState.localPlayer, gameState.currentGuess, gameState.clueGiverId]);

  const handleNextActionAfterReveal = useCallback(() => {
    // This logic will be mostly server-side (score calculation, determining game over).
    // Client might send a "READY_FOR_NEXT_ROUND" or server automatically proceeds.
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.roomId) {
        socketRef.current.send(JSON.stringify({
            type: 'PROCEED_TO_NEXT', // Or 'REQUEST_NEXT_ROUND'
            payload: { roomId: gameState.roomId }
        }));
    }

    const { scores, clueGiverId, targetPosition, currentGuess, localPlayer, cluesForCurrentGame, currentPreparedClueIndex } = gameState;
    
    if (targetPosition === null || currentGuess === null || !clueGiverId || !localPlayer) return;

    let roundScore = 0;
    const diff = Math.abs(targetPosition - currentGuess);
    for (const band of SCORING_BANDS) {
      if (diff <= band.range) {
        roundScore = band.points;
        break; 
      }
    }
    
    // In a server model, the server calculates and sends updated scores.
    // This is a local calculation for now.
    const playerToScore = localPlayer.id; // Simplified: current player scores their own guess
    const newScores = {
      ...scores,
      [playerToScore]: (scores[playerToScore] || 0) + roundScore,
    };

    const newLogEntry: RoundLogEntry = {
      spectrum: gameState.currentSpectrum!,
      clue: gameState.clue,
      target: targetPosition,
      guess: currentGuess,
      score: roundScore,
      team: localPlayer.name, 
      clueGiverId: clueGiverId,
    };
    
    const updatedRoomPlayers = gameState.roomPlayers.map(p => p.id === playerToScore ? {...p, score: newScores[playerToScore]} : p);


    if (newScores[playerToScore] >= WINNING_SCORE) {
      setGameState(prev => ({
        ...prev,
        scores: newScores,
        roomPlayers: updatedRoomPlayers,
        phase: GamePhase.GAME_SUMMARY,
        roundLog: [...prev.roundLog, newLogEntry],
      }));
    } else {
      const remainingClues = cluesForCurrentGame.filter((clue, index) => index > (currentPreparedClueIndex ?? -1) && !clue.isUsed);
      if (remainingClues.length === 0 && (currentPreparedClueIndex ?? -1) >= cluesForCurrentGame.length -1) {
         setGameState(prev => ({ 
             ...prev, 
             scores: newScores, 
             roomPlayers: updatedRoomPlayers,
             phase: GamePhase.GAME_SUMMARY, 
             roundLog: [...prev.roundLog, newLogEntry] 
            }));
      } else {
        setGameState(prev => ({
          ...prev,
          scores: newScores,
          roomPlayers: updatedRoomPlayers,
          phase: GamePhase.GUESSING_ROUND, 
          currentSpectrum: null, // This triggers setupNextGuessingRound effect
          roundLog: [...prev.roundLog, newLogEntry],
        }));
      }
    }
  }, [gameState]);
  
  const resetGame = useCallback(() => {
    // Client informs server if it's a host action, or client just disconnects/re-enters flow.
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && gameState.roomId && gameState.isHost) {
        socketRef.current.send(JSON.stringify({
            type: 'RESET_GAME_REQUEST', 
            payload: { roomId: gameState.roomId }
        }));
    }
    // For now, local reset:
    setAvailableSpectrums([...SPECTRUMS_HE]);
    setGameState(prev => ({
        ...initialGameState,
        localPlayer: prev.localPlayer, 
        roomPlayers: prev.localPlayer ? [prev.localPlayer] : [], 
        scores: prev.localPlayer ? {[prev.localPlayer.id]: 0} : {},
        phase: GamePhase.ROOM_SETUP, 
    }));
    // Re-establish WebSocket connection if desired for new game, or rely on ROOM_SETUP phase.
    // Current connectWebSocket is called on host/join.
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        console.log("Game reset locally. WebSocket remains open. Consider if it should close and reopen.");
    }

  }, [gameState.roomId, gameState.isHost]);

  // Render logic
  const renderContent = () => {
    // ... (renderContent remains largely the same, but UI might show connecting states)
    // For example, in RoomPage, disable "Start Game" if isConnecting or !isConnected
    // We can pass isConnecting and isConnected as props to relevant components.

    switch (gameState.phase) {
      case GamePhase.PLAYER_DETAILS_SETUP:
        return <HomePage onSubmit={handlePlayerDetailsSubmit} />;
      case GamePhase.ROOM_SETUP:
        return <RoomPage 
                  isHost={gameState.isHost} 
                  roomId={gameState.roomId} 
                  players={gameState.roomPlayers}
                  localPlayerId={gameState.localPlayer?.id}
                  onHostRoom={handleHostRoom} 
                  onJoinRoom={handleJoinRoom} 
                  onStartGame={startCluePreparationPhase}
                  isConnecting={isConnecting}
                  isConnected={isConnected}
                />;
      case GamePhase.CLUE_PREPARATION:
        return <CluePreparationPage
                  spectrumsToPrepare={gameState.spectrumsToPrepare}
                  timeLeft={gameState.cluePreparationTimeLeft}
                  onClueSubmit={handleClueSubmittedDuringPrep}
                  onFinishPreparation={finishCluePreparation}
                  preparedCluesCount={gameState.preparedClues.length}
                  totalCluesToPrepare={NUMBER_OF_CLUES_TO_PREPARE}
                />;
      case GamePhase.GUESSING_ROUND:
      case GamePhase.REVEAL_SCORE:
        if (!gameState.currentSpectrum || !gameState.localPlayer) return <p>טוען משחק... {isConnecting ? "מתחבר לשרת..." : !isConnected ? "לא מחובר לשרת." : ""}</p>;
        
        const isGuessingPhase = gameState.phase === GamePhase.GUESSING_ROUND;
        const canChangeSlider = isGuessingPhase; 
        const showTarget = gameState.phase === GamePhase.REVEAL_SCORE;

        return (
          <main className="w-full max-w-2xl bg-white p-6 rounded-lg shadow-xl">
            <Scoreboard scores={gameState.scores} players={gameState.roomPlayers} activePlayerId={gameState.clueGiverId} />
            <GamePhaseMessage 
              phase={gameState.phase} 
              activeTeam={Team.Team1} 
              psychicTeam={null} 
              currentPlayerName={gameState.roomPlayers.find(p => p.id === gameState.clueGiverId)?.name}
            />
            <SpectrumDisplay leftTerm={gameState.currentSpectrum.left} rightTerm={gameState.currentSpectrum.right} />
            <TargetSlider
              value={gameState.currentGuess ?? 50}
              onChange={canChangeSlider ? handleGuessChange : () => {}}
              disabled={!canChangeSlider || isConnecting || !isConnected} // Disable slider if not connected
              targetPosition={showTarget ? gameState.targetPosition : null}
              scoringBands={SCORING_BANDS}
            />
            {gameState.clue && <ClueArea mode="display" clue={gameState.clue} />}
            <div className="mt-6 flex justify-center space-x-4 space-x-reverse">
              {isGuessingPhase && <button onClick={handleLockGuess} disabled={isConnecting || !isConnected} className="px-6 py-2 bg-secondary text-white rounded hover:bg-orange-700 disabled:bg-neutral-400">נעל ניחוש</button>}
              {gameState.phase === GamePhase.REVEAL_SCORE && <button onClick={handleNextActionAfterReveal} disabled={isConnecting || !isConnected} className="px-6 py-2 bg-accent text-white rounded hover:bg-amber-600 disabled:bg-neutral-400">המשך</button>}
            </div>
          </main>
        );
      case GamePhase.GAME_SUMMARY:
        const winner = gameState.roomPlayers.reduce((prev, curr) => (curr.score > prev.score ? curr : prev), gameState.roomPlayers[0] || gameState.localPlayer);
        return (
          <main className="w-full max-w-2xl bg-white p-6 rounded-lg shadow-xl text-center">
            <h2 className="text-3xl font-bold text-primary mb-4">המשחק הסתיים!</h2>
            {winner && <p className="text-xl mb-2">כל הכבוד ל<span className="font-semibold">{winner.name}</span> על הניצחון עם {winner.score} נקודות!</p>}
            <h3 className="text-lg font-semibold mt-4 mb-2">סיכום נקודות:</h3>
            <ul className="list-none p-0">
              {gameState.roomPlayers.map(p => <li key={p.id} className="text-md">{p.name}: {p.score} נקודות</li>)}
            </ul>
            <button onClick={resetGame} className="mt-8 px-8 py-3 bg-primary text-white text-lg rounded hover:bg-teal-700">שחק שוב</button>
          </main>
        );
      default:
        return <p>טוען שלב משחק...</p>;
    }
  };

  return (
    <div className="container mx-auto p-4 min-h-screen flex flex-col items-center text-neutral-800">
      <header className="mb-8 text-center">
        <h1 className="text-5xl font-bold text-primary">סקאלה</h1>
        {isConnecting && <p className="text-sm text-accent">מתחבר לשרת...</p>}
        {!isConnecting && !isConnected && gameState.phase !== GamePhase.PLAYER_DETAILS_SETUP && <p className="text-sm text-red-500">לא מחובר לשרת המשחק.</p>}
        {!isConnecting && isConnected && gameState.phase !== GamePhase.PLAYER_DETAILS_SETUP && <p className="text-sm text-green-500">מחובר לשרת המשחק.</p>}
      </header>
      
      {renderContent()}

      {gameState.phase !== GamePhase.PLAYER_DETAILS_SETUP && gameState.phase !== GamePhase.ROOM_SETUP && gameState.roundLog.length > 0 && (
        <details className="mt-8 w-full max-w-2xl bg-gray-50 p-4 rounded shadow">
          <summary className="font-semibold cursor-pointer text-neutral-700">יומן סיבובים</summary>
          <ul className="mt-2 space-y-2 text-sm text-neutral-600">
            {gameState.roundLog.map((log, index) => (
              <li key={index} className="p-2 bg-white border border-neutral-200 rounded">
                סיבוב {index + 1} (רמז של: <strong>{gameState.roomPlayers.find(p=>p.id === log.clueGiverId)?.name || 'לא ידוע'}</strong>, ניחוש של: <strong>{log.team}</strong>): 
                ספקטרום "<em>{log.spectrum.left} / {log.spectrum.right}</em>". 
                רמז: "<strong>{log.clue}</strong>". מטרה: <span className="font-mono">{log.target}</span>, 
                ניחוש: <span className="font-mono">{log.guess}</span>. נקודות: <strong>{log.score}</strong>.
              </li>
            ))}
          </ul>
        </details>
      )}
    </div>
  );
};

export default App;


import React, { useState } from 'react';
import { Player } from '../types';

interface RoomPageProps {
  isHost: boolean;
  roomId: string | null;
  players: Player[];
  localPlayerId?: string | null;
  onHostRoom: () => void;
  onJoinRoom: (roomIdInput: string) => void;
  onStartGame: () => void;
  isConnecting: boolean;
  isConnected: boolean;
}

const RoomPage: React.FC<RoomPageProps> = ({ 
  isHost, 
  roomId, 
  players,
  localPlayerId,
  onHostRoom, 
  onJoinRoom, 
  onStartGame,
  isConnecting,
  isConnected
}) => {
  const [joinRoomIdInput, setJoinRoomIdInput] = useState('');

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (joinRoomIdInput.trim().length === 4 && /^\d+$/.test(joinRoomIdInput.trim())) {
      onJoinRoom(joinRoomIdInput.trim());
    } else {
      alert('קוד חדר חייב להיות בן 4 ספרות.');
    }
  };

  const commonButtonClasses = "w-full py-3 px-4 rounded-md text-lg font-semibold transition";
  const disabledButtonClasses = "disabled:bg-neutral-300 disabled:cursor-not-allowed";

  return (
    <div className="w-full max-w-lg mx-auto bg-white p-8 rounded-lg shadow-xl">
      <h2 className="text-3xl font-bold text-center text-primary mb-6">
        {roomId ? `חדר משחק: ${roomId}` : 'הגדרת חדר'}
      </h2>

      {isConnecting && <p className="text-center text-accent mb-4">מתחבר לשרת...</p>}
      {!isConnecting && !isConnected && !roomId && <p className="text-center text-red-500 mb-4">נדרש חיבור לשרת כדי ליצור/להצטרף לחדר.</p>}


      {!roomId && (
        <div className="space-y-4 mb-6">
          <button
            onClick={onHostRoom}
            disabled={isConnecting || !isConnected}
            className={`${commonButtonClasses} bg-primary text-white hover:bg-teal-700 ${disabledButtonClasses}`}
          >
            {isConnecting ? "מתחבר..." : "צור חדר חדש"}
          </button>
          <form onSubmit={handleJoinSubmit} className="flex space-x-2 space-x-reverse">
            <input
              type="text"
              value={joinRoomIdInput}
              onChange={(e) => setJoinRoomIdInput(e.target.value)}
              className="flex-grow p-3 border border-neutral-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
              placeholder="הכנס קוד חדר (4 ספרות)"
              maxLength={4}
              pattern="\d{4}"
              disabled={isConnecting || !isConnected}
            />
            <button
              type="submit"
              disabled={isConnecting || !isConnected || !joinRoomIdInput.trim()}
              className={`${commonButtonClasses} bg-secondary text-white hover:bg-orange-600 ${disabledButtonClasses}`}
            >
              {isConnecting ? "מתחבר..." : "הצטרף"}
            </button>
          </form>
        </div>
      )}

      {roomId && (
        <div className="mb-6">
          {isHost && (
            <p className="text-center text-lg text-neutral-700 mb-4">
              קוד החדר שלך הוא: <strong className="text-2xl text-accent font-mono">{roomId}</strong>. 
              שתף אותו עם חברים!
            </p>
          )}
          {!isHost && (
             <p className="text-center text-lg text-neutral-700 mb-4">
              הצטרפת לחדר <strong className="text-2xl text-accent font-mono">{roomId}</strong>. ממתין למארח...
            </p>
          )}

          <h3 className="text-xl font-semibold text-neutral-800 mb-3">שחקנים בחדר:</h3>
          {players.length > 0 ? (
            <ul className="space-y-2 bg-neutral-50 p-3 rounded-md">
              {players.map((player) => (
                <li key={player.id} className="flex items-center text-neutral-700">
                  <img src={player.avatar} alt={player.name} className="w-8 h-8 rounded-full mr-3 object-cover" />
                  <span>{player.name} {player.id === localPlayerId ? '(את/ה)' : ''} {player.id === players.find(p => p.id === localPlayerId && isHost)?.id && players.length >0 ? '(מארח/ת)' : ''}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-neutral-500">עדיין אין שחקנים בחדר. {isConnecting ? "בודק..." : ""}</p>
          )}
        </div>
      )}

      {roomId && isHost && (
        <button
          onClick={onStartGame}
          disabled={players.length < 1 || isConnecting || !isConnected} 
          className={`${commonButtonClasses} bg-green-500 text-white hover:bg-green-600 ${disabledButtonClasses}`}
        >
          {isConnecting ? "מתחבר..." : (players.length < 1 ? 'ממתין לשחקנים...' : 'התחל הכנת רמזים!')}
        </button>
      )}
    </div>
  );
};

export default RoomPage;

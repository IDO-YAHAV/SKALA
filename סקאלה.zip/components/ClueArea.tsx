
import React, { useState } from 'react';

interface ClueAreaProps {
  mode: 'input' | 'display';
  clue?: string;
  onSubmit?: (clue: string) => void;
}

const ClueArea: React.FC<ClueAreaProps> = ({ mode, clue: initialClue = '', onSubmit }) => {
  const [clueText, setClueText] = useState(mode === 'input' ? '' : initialClue); // Clear input field initially for input mode

  // Update clueText if initialClue changes and it's in display mode
  React.useEffect(() => {
    if (mode === 'display') {
      setClueText(initialClue);
    }
  }, [initialClue, mode]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSubmit && clueText.trim()) {
      onSubmit(clueText.trim());
    } else if (onSubmit && !clueText.trim()) {
        alert("נא להזין רמז!");
    }
  };

  if (mode === 'input') {
    return (
      <form onSubmit={handleSubmit} className="my-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <label htmlFor="clueInput" className="block text-sm font-medium text-yellow-800 mb-1">
          הקלד/י את הרמז שלך (מילה אחת או ביטוי קצר):
        </label>
        <div className="flex items-center space-x-2 space-x-reverse"> {/* space-x-reverse for RTL */}
          <input
            id="clueInput"
            type="text"
            value={clueText}
            onChange={(e) => setClueText(e.target.value)}
            className="flex-grow p-2 border border-yellow-400 rounded-md shadow-sm focus:ring-accent focus:border-accent text-neutral-800"
            placeholder="לדוגמה: 'כלב קטן'"
            maxLength={50}
            autoFocus
          />
          <button 
            type="submit" 
            className="px-4 py-2 bg-primary text-white rounded-md hover:bg-teal-700 transition"
          >
            הגש רמז
          </button>
        </div>
      </form>
    );
  }

  return (
    <div className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-lg text-center">
      <p className="text-sm font-medium text-sky-700">הרמז שניתן:</p>
      <p className="text-2xl font-semibold text-sky-900 break-words">{clueText}</p>
    </div>
  );
};

export default ClueArea;
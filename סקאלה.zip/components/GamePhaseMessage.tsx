
import React from 'react';
import { GamePhase, Team } from '../types'; // Team might be deprecated or used differently

interface GamePhaseMessageProps {
  phase: GamePhase;
  activeTeam?: Team | null; // Keep for now, might be replaced by player names
  psychicTeam?: Team | null; // Keep for now, might be replaced by player names
  winnerName?: string | null;
  currentPlayerName?: string | null; // Name of the player whose turn it is (e.g. clue giver, or local player)
  timeLeft?: number; // For timers
  roomID?: string | null;
  isHost?: boolean;
}

const GamePhaseMessage: React.FC<GamePhaseMessageProps> = ({ 
  phase, 
  winnerName, 
  currentPlayerName, 
  timeLeft,
  roomID,
  isHost
}) => {
  let message = '';
  let baseClasses = 'p-4 my-4 rounded-lg text-center font-medium border text-sm md:text-base';
  let specificClasses = '';

  switch (phase) {
    case GamePhase.PLAYER_DETAILS_SETUP:
      message = "ברוכים הבאים! הזינו את שמכם ובחרו אווטאר כדי להתחיל.";
      specificClasses = 'bg-indigo-100 border-indigo-400 text-indigo-800';
      break;
    case GamePhase.ROOM_SETUP:
      if (roomID) {
        message = isHost 
          ? `החדר שלך נוצר! קוד החדר הוא: ${roomID}. המתן לשחקנים נוספים או התחל את המשחק.`
          : `הצטרפת לחדר ${roomID}. ממתין למארח שיתחיל את המשחק.`;
      } else {
        message = "בחרו: לארח חדר חדש או להצטרף לחדר קיים.";
      }
      specificClasses = 'bg-sky-100 border-sky-400 text-sky-800';
      break;
    case GamePhase.CLUE_PREPARATION:
      message = `הכנת רמזים! ${currentPlayerName || ''}, יש לך ${timeLeft} שניות להכין רמזים לספקטרומים שלך.`;
      specificClasses = 'bg-yellow-100 border-yellow-400 text-yellow-800';
      break;
    case GamePhase.GUESSING_ROUND:
      message = `תור ניחוש! ${currentPlayerName ? `הרמז של ${currentPlayerName}.` : ''} הקבוצה דנה ומנחשת את המיקום.`;
      specificClasses = 'bg-blue-100 border-blue-400 text-blue-800';
      break;
    case GamePhase.REVEAL_SCORE:
      message = `חושפים את המטרה! בואו נראה כמה קרוב הניחוש...`;
      specificClasses = 'bg-green-100 border-green-400 text-green-800';
      break;
    case GamePhase.GAME_SUMMARY:
      message = winnerName ? `המשחק נגמר! ${winnerName} ניצח/ה!` : 'המשחק נגמר!';
      specificClasses = 'bg-purple-100 border-purple-400 text-purple-800 text-lg';
      break;
    default:
      // Fallback for old phases if any are still temporarily hit, or new unhandled ones
      message = `שלב: ${phase}`;
      specificClasses = 'bg-gray-100 border-gray-300 text-gray-700';
      // return null; // Or some default message
  }

  return (
    <div className={`${baseClasses} ${specificClasses}`}>
      <p>{message}</p>
    </div>
  );
};

export default GamePhaseMessage;

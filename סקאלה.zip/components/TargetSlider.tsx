import React, { useCallback, useMemo } from 'react';
import { ScoringBand } from '../types';

interface TargetSliderProps {
  value: number; // Current guess (0-100)
  onChange: (value: number) => void;
  disabled: boolean;
  targetPosition?: number | null; // Actual target (0-100), revealed later
  scoringBands: ScoringBand[];
}

const ARC_WIDTH = 280; // Width of the arc container
const ARC_HEIGHT = ARC_WIDTH / 2; // Height of the semi-circle (radius)
const ARC_THICKNESS = 40; // Thickness of the blue arc track
const THUMB_SIZE = 36; // Diameter of the red thumb
const TARGET_MARKER_SIZE = 16; // Diameter of the yellow target marker

// Helper function to calculate position on the arc
const calculateArcPosition = (percentage: number, radiusOffset = 0, elementSize = 0) => {
  const arcRadius = ARC_HEIGHT - (ARC_THICKNESS / 2) - radiusOffset; // Radius to the center of the track or element
  const angleRad = Math.PI - (percentage / 100) * Math.PI; // Angle from PI (left) to 0 (right)
  
  // Center of the arc's bounding box (assuming origin 0,0 for these calculations)
  const centerX = ARC_WIDTH / 2;
  const centerY = ARC_HEIGHT; // Center of the base of the semi-circle

  const x = centerX + arcRadius * Math.cos(angleRad) - elementSize / 2;
  const y = centerY - arcRadius * Math.sin(angleRad) - elementSize / 2;
  
  return { x, y, angleRad };
};


const TargetSlider: React.FC<TargetSliderProps> = ({
  value,
  onChange,
  disabled,
  targetPosition,
  scoringBands,
}) => {

  const thumbPosition = useMemo(() => calculateArcPosition(value, 0, THUMB_SIZE), [value]);

  const targetMarkerPosition = useMemo(() => {
    if (targetPosition === null || typeof targetPosition === 'undefined') return null;
    return calculateArcPosition(targetPosition, 0, TARGET_MARKER_SIZE);
  }, [targetPosition]);

  const getBandPath = useCallback((bandRange: number, bandPoints: number, currentTargetPos: number) => {
    const innerRadius = ARC_HEIGHT - ARC_THICKNESS;
    const outerRadius = ARC_HEIGHT;

    const startPercentage = Math.max(0, currentTargetPos - bandRange);
    const endPercentage = Math.min(100, currentTargetPos + bandRange);

    const startAngle = Math.PI - (startPercentage / 100) * Math.PI;
    const endAngle = Math.PI - (endPercentage / 100) * Math.PI;

    const startXOuter = ARC_WIDTH / 2 + outerRadius * Math.cos(startAngle);
    const startYOuter = ARC_HEIGHT - outerRadius * Math.sin(startAngle);
    const endXOuter = ARC_WIDTH / 2 + outerRadius * Math.cos(endAngle);
    const endYOuter = ARC_HEIGHT - outerRadius * Math.sin(endAngle);

    const startXInner = ARC_WIDTH / 2 + innerRadius * Math.cos(startAngle);
    const startYInner = ARC_HEIGHT - innerRadius * Math.sin(startAngle);
    const endXInner = ARC_WIDTH / 2 + innerRadius * Math.cos(endAngle);
    const endYInner = ARC_HEIGHT - innerRadius * Math.sin(endAngle);
    
    const d = `
      M ${startXOuter} ${startYOuter}
      A ${outerRadius} ${outerRadius} 0 0 0 ${endXOuter} ${endYOuter}
      L ${endXInner} ${endYInner}
      A ${innerRadius} ${innerRadius} 0 0 1 ${startXInner} ${startYInner}
      Z
    `;
    
    // Scoring bands are light/transparent to show on top of the blue arc
    let color = 'rgba(255,255,255,0.1)'; // Default, least points
    if (bandPoints === 4) color = 'rgba(255, 255, 255, 0.4)'; // Most points, most visible
    else if (bandPoints === 3) color = 'rgba(255, 255, 255, 0.3)';
    else if (bandPoints === 2) color = 'rgba(255, 255, 255, 0.2)';

    return <path key={`band-${bandPoints}`} d={d} fill={color} />;
  }, []);


  return (
    <div 
      className="relative p-4 rounded-lg disable-touch-highlight mx-auto" 
      style={{ 
        width: ARC_WIDTH + 32, 
        height: ARC_HEIGHT + THUMB_SIZE / 2 + 32, // Adjusted for thumb overflow + padding
      }}
      dir="ltr" // Ensure LTR for positioning logic
    >
      <div 
        className="relative mx-auto" // mx-auto for centering within the parent div if parent is wider
        style={{ width: ARC_WIDTH, height: ARC_HEIGHT }}
      >
        {/* Base Arc Track (Light Blue Semi-circle) */}
        <svg width={ARC_WIDTH} height={ARC_HEIGHT} viewBox={`0 0 ${ARC_WIDTH} ${ARC_HEIGHT}`} className="absolute top-0 left-0">
          <defs>
            <clipPath id="arcClipPath">
              <rect x="0" y="0" width={ARC_WIDTH} height={ARC_HEIGHT} />
            </clipPath>
             <path 
                id="arcPathDef"
                d={`M ${ARC_THICKNESS/2} ${ARC_HEIGHT} 
                    A ${ARC_HEIGHT - ARC_THICKNESS/2} ${ARC_HEIGHT - ARC_THICKNESS/2} 0 0 1 ${ARC_WIDTH - ARC_THICKNESS/2} ${ARC_HEIGHT}`}
                fill="none"
              />
          </defs>
          <path 
            d={`M 0 ${ARC_HEIGHT} 
                A ${ARC_HEIGHT} ${ARC_HEIGHT} 0 0 1 ${ARC_WIDTH} ${ARC_HEIGHT} 
                L ${ARC_WIDTH - ARC_THICKNESS} ${ARC_HEIGHT} 
                A ${ARC_HEIGHT - ARC_THICKNESS} ${ARC_HEIGHT - ARC_THICKNESS} 0 0 0 ${ARC_THICKNESS} ${ARC_HEIGHT} 
                Z`}
            fill="rgb(56 189 248)" // sky-400
          />
          
          {/* Scoring Bands - visible on reveal */}
          {targetPosition !== null && typeof targetPosition !== 'undefined' && scoringBands.map(band => 
            getBandPath(band.range, band.points, targetPosition)
          )}
        </svg>

        {/* Target Marker - visible on reveal */}
        {targetMarkerPosition && (
          <div
            className="absolute bg-yellow-400 rounded-full shadow-md z-20 pointer-events-none"
            style={{
              width: TARGET_MARKER_SIZE,
              height: TARGET_MARKER_SIZE,
              left: targetMarkerPosition.x,
              top: targetMarkerPosition.y,
            }}
            title={`מטרה: ${targetPosition}`}
            aria-label={`מטרה במיקום ${targetPosition}`}
          />
        )}
        
        {/* Movable Thumb (Pink Circle) */}
        <div
          className="absolute bg-pink-500 rounded-full border-2 sm:border-4 border-white shadow-xl z-30 flex items-center justify-center pointer-events-none"
          style={{
            width: THUMB_SIZE,
            height: THUMB_SIZE,
            left: thumbPosition.x,
            top: thumbPosition.y,
          }}
          title={`ניחוש נוכחי`}
          aria-label={`ניחוש נוכחי במיקום ${value}`}
        >
           {/* Number displaying value removed as per request */}
        </div>
      </div>
      
      <input
        type="range"
        min="0"
        max="100"
        step="1"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value, 10))}
        disabled={disabled}
        className="absolute bottom-0 left-0 w-full h-1/2 opacity-0 cursor-pointer z-40"
        style={{ height: ARC_HEIGHT/2, top: ARC_HEIGHT/2 + (THUMB_SIZE/4) }} // Covers lower half of arc for easier interaction
        aria-label="בחר מיקום על הסקאלה"
      />
    </div>
  );
};

export default TargetSlider;
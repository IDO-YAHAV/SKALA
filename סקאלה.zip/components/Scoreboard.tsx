
import React from 'react';
import { Player } from '../types'; // Assuming Team might be replaced or supplemented by Player specific data

interface ScoreboardProps {
  scores: { [playerId: string]: number }; // Scores indexed by player ID
  players: Player[]; // Array of player objects
  activePlayerId?: string | null; // ID of the currently "active" player (e.g., clue giver)
}

const Scoreboard: React.FC<ScoreboardProps> = ({ scores, players, activePlayerId }) => {
  // Sort players for consistent display order, or display as is
  const sortedPlayers = [...players].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="flex flex-wrap justify-around mb-6 p-4 bg-neutral-100 rounded-lg shadow">
      {sortedPlayers.map(player => (
        <div 
          key={player.id} 
          className={`text-center p-3 m-1 rounded-md transition-all duration-300 min-w-[100px] ${activePlayerId === player.id ? 'ring-2 ring-accent scale-105' : 'opacity-80'}`}
        >
          <div className="flex items-center justify-center mb-1">
            <img src={player.avatar} alt={player.name} className="w-8 h-8 rounded-full mr-2 object-cover"/>
            <h2 className={`text-xl font-semibold text-primary`}>{player.name}</h2>
          </div>
          <p className="text-3xl font-bold text-neutral-700">{scores[player.id] || 0}</p>
        </div>
      ))}
      {players.length === 0 && <p className="text-neutral-500">מחכה לשחקנים...</p>}
    </div>
  );
};

export default Scoreboard;


import React, { useState } from 'react';
import { AVATAR_OPTIONS } from '../constants';

interface HomePageProps {
  onSubmit: (name: string, avatar: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState<string>(AVATAR_OPTIONS[0]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('נא להזין שם שחקן.');
      return;
    }
    if (!selectedAvatar) {
      alert('נא לבחור אווטאר.');
      return;
    }
    onSubmit(name.trim(), selectedAvatar);
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white p-8 rounded-lg shadow-xl">
      <h2 className="text-3xl font-bold text-center text-primary mb-6">ברוכים הבאים לסקאלה!</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="playerName" className="block text-sm font-medium text-neutral-700 mb-1">
            שם שחקן:
          </label>
          <input
            type="text"
            id="playerName"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 border border-neutral-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
            placeholder="הקלד/י את שמך"
            maxLength={20}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-neutral-700 mb-2">
            בחר/י אווטאר:
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {AVATAR_OPTIONS.map((avatarUrl) => (
              <img
                key={avatarUrl}
                src={avatarUrl}
                alt="Avatar option"
                onClick={() => setSelectedAvatar(avatarUrl)}
                className={`w-16 h-16 rounded-full object-cover cursor-pointer transition-all duration-200 ${selectedAvatar === avatarUrl ? 'ring-4 ring-accent scale-110' : 'ring-2 ring-transparent hover:ring-secondary'}`}
                role="button"
                tabIndex={0}
                onKeyPress={(e) => e.key === 'Enter' && setSelectedAvatar(avatarUrl)}

              />
            ))}
          </div>
           {selectedAvatar && <img src={selectedAvatar} alt="Selected avatar preview" className="w-20 h-20 rounded-full object-cover mx-auto mt-4 ring-2 ring-primary"/>}
        </div>

        <button
          type="submit"
          className="w-full bg-primary text-white py-3 px-4 rounded-md text-lg font-semibold hover:bg-teal-700 transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
        >
          המשך לחדר המשחק
        </button>
      </form>
    </div>
  );
};

export default HomePage;

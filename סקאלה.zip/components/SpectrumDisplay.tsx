
import React from 'react';

interface SpectrumDisplayProps {
  leftTerm: string;
  rightTerm: string;
}

const SpectrumDisplay: React.FC<SpectrumDisplayProps> = ({ leftTerm, rightTerm }) => {
  return (
    <div className="flex justify-between items-center my-6 px-2 text-neutral-700">
      <div className="text-lg font-medium text-left w-2/5 break-words">{leftTerm}</div>
      <div className="text-xl font-bold text-neutral-500 mx-2">&harr;</div>
      <div className="text-lg font-medium text-right w-2/5 break-words">{rightTerm}</div>
    </div>
  );
};

export default SpectrumDisplay;
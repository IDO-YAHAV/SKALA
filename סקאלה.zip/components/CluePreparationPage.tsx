
import React, { useState, useEffect } from 'react';
import { Spectrum } from '../types';
import SpectrumDisplay from './SpectrumDisplay';
import TargetSlider from './TargetSlider'; // To show target
import ClueArea from './ClueArea'; // For input

interface SpectrumToPrepare {
  spectrum: Spectrum;
  targetPosition: number;
}

interface CluePreparationPageProps {
  spectrumsToPrepare: SpectrumToPrepare[];
  timeLeft: number;
  onClueSubmit: (clueText: string, spectrum: Spectrum, targetPosition: number) => void;
  onFinishPreparation: () => void;
  preparedCluesCount: number;
  totalCluesToPrepare: number;
}

const CluePreparationPage: React.FC<CluePreparationPageProps> = ({
  spectrumsToPrepare,
  timeLeft,
  onClueSubmit,
  onFinishPreparation,
  preparedCluesCount,
  totalCluesToPrepare
}) => {
  const [currentClueInputs, setCurrentClueInputs] = useState<{[spectrumId: string]: string}>({});
  const [submittedClues, setSubmittedClues] = useState<{[spectrumId: string]: boolean}>({});


  const handleSingleClueSubmit = (spectrumId: string, spectrum: Spectrum, targetPosition: number) => {
    const clueText = currentClueInputs[spectrumId];
    if (clueText && clueText.trim()) {
      onClueSubmit(clueText.trim(), spectrum, targetPosition);
      setSubmittedClues(prev => ({...prev, [spectrumId]: true}));
    } else {
      alert("נא להזין רמז.");
    }
  };
  
  const handleInputChange = (spectrumId: string, value: string) => {
    setCurrentClueInputs(prev => ({...prev, [spectrumId]: value}));
  };

  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-xl">
      <h2 className="text-3xl font-bold text-center text-primary mb-2">הכנת רמזים</h2>
      <p className="text-center text-neutral-600 mb-1">
        הכן/י רמז עבור כל ספקטרום. המטרה (קו אדום) גלויה רק לך.
      </p>
      <div className="my-4 p-3 bg-yellow-100 border border-yellow-300 rounded-md text-center">
        <p className="text-xl font-semibold text-yellow-800">
          זמן נותר: <span className="font-mono text-2xl">{formatTime(timeLeft)}</span>
        </p>
         <p className="text-sm text-yellow-700">רמזים שהוכנו: {preparedCluesCount} / {totalCluesToPrepare}</p>
      </div>

      <div className="space-y-8">
        {spectrumsToPrepare.map(({ spectrum, targetPosition }, index) => (
          <div key={spectrum.id || index} className="p-4 border border-neutral-200 rounded-lg bg-neutral-50">
            <h3 className="text-lg font-semibold text-neutral-700 mb-1">ספקטרום #{index + 1}</h3>
            <SpectrumDisplay leftTerm={spectrum.left} rightTerm={spectrum.right} />
            <TargetSlider
              value={targetPosition} // Show actual target
              onChange={() => {}} // Not changeable by user here
              disabled={true}
              targetPosition={targetPosition} // Make target visible
              scoringBands={[]} // Not relevant for psychic view of target
            />
             <p className="text-xs text-center text-neutral-500 mb-3">מיקום מטרה סודי (גלוי לך): {targetPosition}</p>
            
            {submittedClues[spectrum.id] ? (
                 <div className="my-3 p-3 bg-green-50 border border-green-200 rounded-lg text-center">
                    <p className="text-sm font-medium text-green-700">הרמז שהוגש עבור ספקטרום זה:</p>
                    <p className="text-xl font-semibold text-green-900 break-words">{currentClueInputs[spectrum.id]}</p>
                </div>
            ) : (
                <form onSubmit={(e) => { e.preventDefault(); handleSingleClueSubmit(spectrum.id, spectrum, targetPosition);}} className="my-3">
                    <label htmlFor={`clueInput-${spectrum.id}`} className="block text-sm font-medium text-neutral-700 mb-1">
                        הקלד/י רמז (מילה אחת או ביטוי קצר):
                    </label>
                    <div className="flex items-center space-x-2 space-x-reverse">
                    <input
                        id={`clueInput-${spectrum.id}`}
                        type="text"
                        value={currentClueInputs[spectrum.id] || ''}
                        onChange={(e) => handleInputChange(spectrum.id, e.target.value)}
                        className="flex-grow p-2 border border-neutral-300 rounded-md shadow-sm focus:ring-accent focus:border-accent text-neutral-800"
                        placeholder="לדוגמה: 'גבוה מאוד'"
                        maxLength={50}
                        required
                    />
                    <button 
                        type="submit" 
                        className="px-4 py-2 bg-primary text-white rounded-md hover:bg-teal-700 transition"
                    >
                        שמור רמז זה
                    </button>
                    </div>
              </form>
            )}
          </div>
        ))}
      </div>

      {preparedCluesCount >= totalCluesToPrepare && timeLeft > 0 && (
         <p className="text-center text-green-600 mt-4 font-semibold">כל הרמזים הוכנו! אפשר לסיים מוקדם.</p>
      )}

      <button
        onClick={onFinishPreparation}
        disabled={timeLeft === 0 && preparedCluesCount < totalCluesToPrepare} // Disable if time up and not all clues prepared
        className="w-full mt-8 bg-green-500 text-white py-3 px-4 rounded-md text-lg font-semibold hover:bg-green-600 transition disabled:bg-neutral-400"
      >
        {preparedCluesCount < totalCluesToPrepare && timeLeft > 0 ? `סיים והגש ${preparedCluesCount}/${totalCluesToPrepare} רמזים` : 'המשך למשחק!'}
      </button>
    </div>
  );
};

export default CluePreparationPage;
